package cn.best.approveservice.entity;

import java.io.Serializable;

/**
 * (JfDatainfo)实体类
 *
 * @author makejava
 * @since 2021-04-08 10:17:56
 */
public class JfDatainfo implements Serializable {
    private static final long serialVersionUID = -66214187944272588L;
    /**
     * 主键
     */
    private Integer id;
    /**
     * 检测日期
     */
    private String time;
    /**
     * 频率
     */
    private String rcf;
    /**
     * 最大db值
     */
    private String maxdb;
    /**
     * 平均db值
     */
    private String avedb;
    /**
     * 缺陷程度
     */
    private String defect;
    /**
     * 温度
     */
    private String temperature;
    /**
     * 湿度
     */
    private String humidity;
    /**
     * 经度
     */
    private String longitude;
    /**
     * 维度
     */
    private String latitude;
    /**
     * 音频
     */
    private String voicepath;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getRcf() {
        return rcf;
    }

    public void setRcf(String rcf) {
        this.rcf = rcf;
    }

    public String getMaxdb() {
        return maxdb;
    }

    public void setMaxdb(String maxdb) {
        this.maxdb = maxdb;
    }

    public String getAvedb() {
        return avedb;
    }

    public void setAvedb(String avedb) {
        this.avedb = avedb;
    }

    public String getDefect() {
        return defect;
    }

    public void setDefect(String defect) {
        this.defect = defect;
    }

    public String getTemperature() {
        return temperature;
    }

    public void setTemperature(String temperature) {
        this.temperature = temperature;
    }

    public String getHumidity() {
        return humidity;
    }

    public void setHumidity(String humidity) {
        this.humidity = humidity;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getVoicepath() {
        return voicepath;
    }

    public void setVoicepath(String voicepath) {
        this.voicepath = voicepath;
    }

}
