package cn.best.approveservice.entity;

import java.util.Date;
import java.io.Serializable;

/**
 * (Role)实体类
 *
 * @author makejava
 * @since 2021-04-08 10:17:58
 */
public class Role implements Serializable {
    private static final long serialVersionUID = 717448143412026073L;
    /**
     * 主键
     */
    private Integer id;
    /**
     * 角色0:超管,1:用户,2:子用户
     */
    private Integer role;
    /**
     * 状态:0:启用,1:禁用
     */
    private Integer status;
    /**
     * 创建时间
     */
    private Date creationTime;
    /**
     * 更新时间
     */
    private Date updateTime;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getRole() {
        return role;
    }

    public void setRole(Integer role) {
        this.role = role;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Date getCreationTime() {
        return creationTime;
    }

    public void setCreationTime(Date creationTime) {
        this.creationTime = creationTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

}
