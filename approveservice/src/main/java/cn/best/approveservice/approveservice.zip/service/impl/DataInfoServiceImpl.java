package cn.best.approveservice.service.impl;

import cn.best.approveservice.dao.DataInfoDao;
import cn.best.approveservice.entity.DataInfo;
import cn.best.approveservice.service.DataInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DataInfoServiceImpl implements DataInfoService {

    @Autowired
    private DataInfoDao dataInfoDao;

    @Override
    public List<DataInfo> queryAllByLimit(int offset, int limit) {
        List<DataInfo> list = dataInfoDao.queryAllByLimit(offset, limit);
        return list;
    }
}
