package cn.best.approveservice.dao;
import cn.best.approveservice.entity.DataInfo;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;
import java.util.List;
@Repository
public interface DataInfoDao {

    List<DataInfo> queryAllByLimit(@Param("offset") int offset, @Param("limit") int limit);

}
