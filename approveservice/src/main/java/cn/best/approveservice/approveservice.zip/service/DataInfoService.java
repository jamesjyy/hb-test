package cn.best.approveservice.service;

import cn.best.approveservice.dao.DataInfoDao;
import cn.best.approveservice.entity.DataInfo;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface DataInfoService {

    List<DataInfo> queryAllByLimit(@Param("offset") int offset, @Param("limit") int limit);

}
