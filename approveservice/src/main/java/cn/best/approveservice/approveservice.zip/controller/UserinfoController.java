package cn.best.approveservice.controller;

import cn.best.approveservice.common.utils.CommonUtil;
import cn.best.approveservice.entity.Userinfo;
import cn.best.approveservice.response.Response;
import cn.best.approveservice.service.UserinfoService;
import com.github.pagehelper.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.IncorrectCredentialsException;
import org.apache.shiro.authc.LockedAccountException;
import org.apache.shiro.authc.UnknownAccountException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.crypto.hash.Md5Hash;
import org.apache.shiro.session.Session;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 用户表(Userinfo)表控制层
 *
 * @author makejava
 * @since 2020-07-15 18:28:46
 */
@Api(tags = "用户管理")
@RestController
@RequestMapping("/users")
public class UserinfoController extends BaseController {
    @Autowired
    Response response;
    /**
     * 服务对象
     */
    @Autowired
    private UserinfoService userinfoService;

    /**
     * 通过主键查询单条数据
     *
     * @param id 主键
     * @return 单条数据
     */
    @GetMapping("/selectOne")
    public Userinfo selectOne(Integer id) {
        return this.userinfoService.queryById(id);
    }

    @ApiOperation(value = "用户登录", notes = "用户登录", httpMethod = "POST")
    @PostMapping("/doLogin")
    public Response doLogin(String username, String password, String id, HttpSession session) {
        Subject subject = SecurityUtils.getSubject();
        String Md5Pass = new Md5Hash(password).toHex();
        UsernamePasswordToken token = new UsernamePasswordToken(username, Md5Pass, false);
        try {
            subject.login(token);
            String sessionId = (String) subject.getSession().getId();
            Map<String, Object> map = new HashMap<>();
            session.setAttribute("user", subject.getPrincipal());
//            session.setAttribute("username",username);
//            session.getAttribute("username");
            map.put("sessionId", sessionId);
            map.put("user", subject.getPrincipal());
            return response.success(map);
        } catch (UnknownAccountException e) {
            return response.failure("账号不存在");
        } catch (IncorrectCredentialsException e) {
            return response.failure("密码错误");
        } catch (LockedAccountException e) {
            return response.failure("用户已被锁定");
        }

    }

    @RequestMapping(value = "/islogin")
    @ResponseBody
    public Response islogin() {
        Map<String, Object> data = new HashMap<>();
        Response response = new Response();
        Boolean bol1 = false;
        Boolean bol2 = true;
        if (this.getSessionUser().getIsworkuser().equals("1")) {
            data.put("flg", bol2);

        } else {
            data.put("flg", bol1);
        }
        return response.success(data);
    }

    @ApiOperation(value = "分页查询", notes = "用户管理分页查询", httpMethod = "GET")
    @GetMapping(value = "/getUserinfoListByPage", produces = "application/json")
    public Response getUserinfoListByPage(Userinfo userinfo, @RequestParam(defaultValue = "1") Integer pageNum
            , @RequestParam(defaultValue = "15") Integer pageSize) {
        Response response = new Response();
        List<Userinfo> list = this.userinfoService.getUserinfoListByPage(userinfo, pageNum, pageSize);
        Map<String, Object> data = new HashMap<>();
        data.put("list", list);
        data.put("total", ((Page) list).getTotal());
        return response.success(data);
    }

    /**
     * 修改数据
     *
     * @param userinfo 要修改的数据，必须包含主键
     * @return 修改结果
     */
    @ApiOperation("根据ID修改用户信息")
    @PostMapping(value = "/updateUserinfoById", produces = "application/json")
    public Response updateUserinfoById(Userinfo userinfo) {
        Response response = new Response();
        Userinfo userinfo1 = this.userinfoService.update(userinfo);
        return CommonUtil.isNull(userinfo1) ? response.failure("修改数据出现问题！") : response.success(userinfo);
    }

    /**
     * 新增数据
     *
     * @param userinfo 要新增的数据，主键必须为null
     * @return 修改结果
     */
    @ApiOperation("新增用户信息")
    @PostMapping(value = "/insertUserinfo", produces = "application/json")
    public Response insertUserinfo(Userinfo userinfo) {
        Response response = new Response();
        Userinfo userinfo1 = this.userinfoService.insert(userinfo);
        return CommonUtil.isNull(userinfo1) ? response.failure("新增数据出现问题！") : response.success(userinfo);
    }

}