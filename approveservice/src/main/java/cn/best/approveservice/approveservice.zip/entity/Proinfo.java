package cn.best.approveservice.entity;

import java.io.Serializable;

/**
 * (Proinfo)实体类
 *
 * @author makejava
 * @since 2021-04-08 10:17:57
 */
public class Proinfo implements Serializable {
    private static final long serialVersionUID = 943580826142957365L;
    /**
     * 主键
     */
    private Integer id;
    /**
     * 版本号
     */
    private String version;
    /**
     * 产品串号
     */
    private String imei;
    /**
     * 使用人/公司名称
     */
    private String uname;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public String getUname() {
        return uname;
    }

    public void setUname(String uname) {
        this.uname = uname;
    }

}
