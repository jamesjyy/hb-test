package cn.best.approveservice.service.impl;

import cn.best.approveservice.entity.JfDatainfo;
import cn.best.approveservice.dao.JfDatainfoDao;
import cn.best.approveservice.service.JfDatainfoService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * (JfDatainfo)表服务实现类
 *
 * @author makejava
 * @since 2021-04-08 10:17:56
 */
@Service("jfDatainfoService")
public class JfDatainfoServiceImpl implements JfDatainfoService {
    @Resource
    private JfDatainfoDao jfDatainfoDao;

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    @Override
    public JfDatainfo queryById(Integer id) {
        return this.jfDatainfoDao.queryById(id);
    }

    /**
     * 查询多条数据
     *
     * @param offset 查询起始位置
     * @param limit  查询条数
     * @return 对象列表
     */
    @Override
    public List<JfDatainfo> queryAllByLimit(int offset, int limit) {
        return this.jfDatainfoDao.queryAllByLimit(offset, limit);
    }

    /**
     * 新增数据
     *
     * @param jfDatainfo 实例对象
     * @return 实例对象
     */
    @Override
    public JfDatainfo insert(JfDatainfo jfDatainfo) {
        this.jfDatainfoDao.insert(jfDatainfo);
        return jfDatainfo;
    }

    /**
     * 修改数据
     *
     * @param jfDatainfo 实例对象
     * @return 实例对象
     */
    @Override
    public JfDatainfo update(JfDatainfo jfDatainfo) {
        this.jfDatainfoDao.update(jfDatainfo);
        return this.queryById(jfDatainfo.getId());
    }

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 是否成功
     */
    @Override
    public boolean deleteById(Integer id) {
        return this.jfDatainfoDao.deleteById(id) > 0;
    }
}
