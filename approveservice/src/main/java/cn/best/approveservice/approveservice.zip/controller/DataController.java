package cn.best.approveservice.controller;

import cn.best.approveservice.entity.DataInfo;
import cn.best.approveservice.service.DataInfoService;
import io.swagger.annotations.Api;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Api(tags = "上传文件管理")
@RestController
@RequestMapping("/datainfo")
public class DataController {
    @Autowired
    private DataInfoService dataInfoService;

    @RequestMapping(value = "/views")
    @ResponseBody
    public Map<String, Object> checkviews() {
        Map<String, Object> data = new HashMap<>();
        Integer offset = 1;
        Integer limit = 2;
        List<DataInfo> list = dataInfoService.queryAllByLimit(offset, limit);
        data.put("list", list);
        return data;
    }
}

