package cn.best.approveservice.controller;

import cn.best.approveservice.entity.DyDatainfo;
import cn.best.approveservice.service.DyDatainfoService;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
 * (DyDatainfo)表控制层
 *
 * @author makejava
 * @since 2021-04-08 10:17:55
 */
@RestController
@RequestMapping("dyDatainfo")
public class DyDatainfoController {
    /**
     * 服务对象
     */
    @Resource
    private DyDatainfoService dyDatainfoService;

    /**
     * 通过主键查询单条数据
     *
     * @param id 主键
     * @return 单条数据
     */
    @GetMapping("selectOne")
    public DyDatainfo selectOne(Integer id) {
        return this.dyDatainfoService.queryById(id);
    }

}
