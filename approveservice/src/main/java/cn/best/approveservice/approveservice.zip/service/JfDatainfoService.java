package cn.best.approveservice.service;

import cn.best.approveservice.entity.JfDatainfo;

import java.util.List;

/**
 * (JfDatainfo)表服务接口
 *
 * @author makejava
 * @since 2021-04-08 10:17:56
 */
public interface JfDatainfoService {

    /**
     * 通过ID查询单条数据
     *
     * @param id 主键
     * @return 实例对象
     */
    JfDatainfo queryById(Integer id);

    /**
     * 查询多条数据
     *
     * @param offset 查询起始位置
     * @param limit  查询条数
     * @return 对象列表
     */
    List<JfDatainfo> queryAllByLimit(int offset, int limit);

    /**
     * 新增数据
     *
     * @param jfDatainfo 实例对象
     * @return 实例对象
     */
    JfDatainfo insert(JfDatainfo jfDatainfo);

    /**
     * 修改数据
     *
     * @param jfDatainfo 实例对象
     * @return 实例对象
     */
    JfDatainfo update(JfDatainfo jfDatainfo);

    /**
     * 通过主键删除数据
     *
     * @param id 主键
     * @return 是否成功
     */
    boolean deleteById(Integer id);

}
